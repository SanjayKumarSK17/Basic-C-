﻿using System;
using System.Security.Cryptography;
namespace DateTimeAssign;
class Program
{
    public static void Main(string[] args)
    {
            DateTime date=new DateTime(2021,8,10,10,40,32);
            Console.WriteLine("DATE: "+date);
            Console.WriteLine(date.Year);
            Console.WriteLine(date.Month);
            Console.WriteLine(date.Day);
            Console.WriteLine(date.Hour);
            Console.WriteLine(date.Minute);
            Console.WriteLine(date.Second);
            Console.WriteLine();
            string date1=date.ToString("tt ss mm hh dd MM yyyy");
            Console.WriteLine("Output: " +date1);
            Console.WriteLine();
            DateTime newdate;
            Console.WriteLine("Enter a Date in this format: (yyyy/MM/dd hh:mm:ss tt)");
            bool temp=DateTime.TryParseExact(Console.ReadLine(), "yyyy/MM/dd hh:mm:ss tt",null,System.Globalization.DateTimeStyles.None,out newdate);
            if(!temp)
            {
                Console.WriteLine("Invalid Format.");
            }
            else
            {
                Console.WriteLine(newdate.ToString("yyyy"));
                Console.WriteLine(newdate.ToString("MM"));
                Console.WriteLine(newdate.ToString("dd"));
            }
    }
}